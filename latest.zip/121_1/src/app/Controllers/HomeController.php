<?PHP
	namespace App\Controllers;
	use App\Models\Student;
	use App\Views\View;
	
	class HomeController{
		public $name = "";
		
		public function __construct($name){
			$this->name = $name;
		}
		
		public static function index(){
			$a    = new Student("aaa");
			$show = $a->show();
			print_r($show);
		}
		
		public static function show_header(){
			$message =  array('Hello', 'Thuan Pham');
			View::render('home/header', $message);
		}
		
		public static function show_sidebar(){
			$message =  array('Hello', 'Thuan Pham');
			View::render('home/index', $message);
		}
		
		public static function show_detail(){
			$message =  array('Hello', 'Thuan Pham');
			View::render('home/detail', $message);
		}
		
		public static function student_list(){
			$message =  array('Hello', 'Thuan Pham');
			View::render('student/student_list', $message);
		}
		
		public static function student_detail(){
			$message =  array('Hello', 'Thuan Pham');
			View::render('student/student_detail', $message);
		}
	}
?>