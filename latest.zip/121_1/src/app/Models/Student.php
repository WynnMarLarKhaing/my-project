<?PHP
	namespace App\Models;
	class Student{
		public $name = "";
		
		public function __construct($name){
			$this->name = $name;
		}
		
		public function show(){
			return array("Volvo", "BMW", "Toyota","Volvo1");
		}
	}
?>