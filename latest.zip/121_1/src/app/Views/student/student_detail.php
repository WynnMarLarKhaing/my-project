<div class="row grid-responsive">
	<div class="column page-heading">
		<div class="large-card">
			<h1>Student Detail</h1>
			<p class="text-large">This is a big 'ole hero unit, you can use this for calling extra attention to featured content or information.</p>
			<p>You could also add a call to action button. <em>(it's basically a jumbotron)</em></p>
			<a class="button">Call to action</a>
		</div>
	</div>
</div>