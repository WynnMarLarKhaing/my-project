<div class="row grid-responsive">
	<div class="column page-heading">
		<div class="large-card">
			<div class="container">
				<ul class="tabs">
					<li class="tab-link current" data-tab="tab-1">Tab One</li>
					<li class="tab-link" data-tab="tab-2">Tab Two</li>
					<li class="tab-link" data-tab="tab-3">Tab Three</li>
					<li class="tab-link" data-tab="tab-4">Tab Four</li>
				</ul>

				<div id="tab-1" class="tab-content current">
					Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
				</div>
				<div id="tab-2" class="tab-content">
					 Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
				</div>
				<div id="tab-3" class="tab-content">
					Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur.
				</div>
				<div id="tab-4" class="tab-content">
					Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
				</div>

			</div><!-- container -->
		</div>
	</div>
</div>








