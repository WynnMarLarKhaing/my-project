<h5>Navigation</h5>
<ul>
	<li><a href="#"><em class="fa fa-home"></em> Home</a></li>
	<li><a href="charts"><em class="fa fa-bar-chart"></em> Charts</a></li>
	<li><a href="widgets"><em class="fa fa fa-clone"></em> Widgets</a></li>
	<li><a href="forms"><em class="fa fa-pencil-square-o"></em> Forms</a></li>
	<li><a href="alerts"><em class="fa fa-warning"></em> Alerts</a></li>
	<li><a href="buttons"><em class="fa fa-hand-o-up"></em> Buttons</a></li>
	<li><a href="tables"><em class="fa fa-table"></em> Tables</a></li>
	<li><a href="grid"><em class="fa fa-columns"></em> Grid</a></li>
	<li><a href="Student_detail"><em class="fa fa-columns"></em> Ha Ha</a></li>
</ul>