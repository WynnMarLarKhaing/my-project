<div class="column column-30 col-site-title"><a href="#" class="site-title float-left">Medialoot</a></div>

<div class="column column-40 col-search"><a href="#" class="search-btn fa fa-search"></a>
	<input type="text" name="" value="" placeholder="Search..." />
</div>
<div class="column column-30">
	<div class="user-section"><a href="#">
		<img src="http://via.placeholder.com/50x50" alt="profile photo" class="circle float-left profile-photo" width="50" height="auto">
		<div class="username">
			<h4>Jane Donovan</h4>
			<p>Administrator</p>
		</div>
	</a></div>
</div>