<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>HTML5 Admin Template</title>
	
	<!-- Google Fonts -->
	<link href="https://fonts.googleapis.com/css?family=Montserrat:300,300i,400,400i,500,500i,600,600i,700" rel="stylesheet">
	
	<!-- Template Styles -->
	<link rel="stylesheet" href="css/font-awesome.min.css">
	
	<!-- CSS Reset -->
	<link rel="stylesheet" href="css/normalize.css">
	
	<!-- Milligram CSS minified -->
	<link rel="stylesheet" href="css/milligram.min.css">
	
	<!-- Main Styles -->
	<link rel="stylesheet" href="css/styles.css">
	<link rel="stylesheet" href="css/student.css">	
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
</head>

<body>
	<?PHP 
		require "../vendor/autoload.php";
		use App\Controllers\HomeController;		
	?>
	<div class="navbar">
		<div class="row">
			<?PHP HomeController::show_header(); ?>
		</div>
	</div>
	<div class="row">
		<div id="sidebar" class="column">
			<?PHP HomeController::show_sidebar(); ?>
		</div>
		<section id="main-content" class="column column-offset-20">
			<?PHP
				if($_SERVER['REQUEST_URI'] == "/Student_detail")
					HomeController::student_detail();
				else if($_SERVER['REQUEST_URI'] == "/grid")
					HomeController::student_list(); 
				else
					HomeController::show_detail(); 
			?>
		</section>
	</div>
	
	<script>	
		$(document).ready(function(){	
			$('ul.tabs li').click(function(){
				var tab_id = $(this).attr('data-tab');

				$('ul.tabs li').removeClass('current');
				$('.tab-content').removeClass('current');

				$(this).addClass('current');
				$("#"+tab_id).addClass('current');
			})
		})
	</script>
</body>
</html> 