<?PHP	
	require "../vendor/autoload.php";
	// use Car\Toyota;
	use App\Controllers\HomeController;
	
	// $car = new Toyota('Belta');
	// echo $car->name;
	
	// $db = new DB('test');
	// echo $db->dbname;
	
	// $kyats = Currency_Converter(13000);
	// echo $kyats;
	
	// $car = new HomeController('Belta');
	// echo $car->index();
	HomeController::index();
	
?>



