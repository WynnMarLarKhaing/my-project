<?PHP
	class DB {
		public $dbname = '';
		public function __construct($dbname) {
			$this->dbname = $dbname;
		}
	}
?>