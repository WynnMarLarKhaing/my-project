<?PHP
	function Currency_Converter($amount) {
		return $amount * 980;
	}
?>